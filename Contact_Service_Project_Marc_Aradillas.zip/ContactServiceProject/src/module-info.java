/**
 * 
 */
/**
 * 
 */
module ContactServiceProject {
	requires org.junit.jupiter.api;
}