package contactservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Service to manage contacts.
 * The contact service allows adding, updating, and deleting contacts.
 */
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the service.
     * 
     * @param contact the contact to add, must have a unique contact ID
     * @throws IllegalArgumentException if a contact with the same ID already exists
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Deletes a contact from the service.
     * 
     * @param contactId the ID of the contact to delete
     * @throws IllegalArgumentException if the contact ID does not exist
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    /**
     * Updates an existing contact in the service.
     * 
     * @param contactId the ID of the contact to update
     * @param firstName the new first name, can be null
     * @param lastName the new last name, can be null
     * @param phone the new phone number, can be null
     * @param address the new address, can be null
     * @throws IllegalArgumentException if the contact ID does not exist
     */
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }

        if (firstName != null) {
            if (firstName.length() > 10) {
                throw new IllegalArgumentException("Invalid first name");
            }
            contact.setFirstName(firstName);
        }

        if (lastName != null) {
            if (lastName.length() > 10) {
                throw new IllegalArgumentException("Invalid last name");
            }
            contact.setLastName(lastName);
        }

        if (phone != null) {
            if (phone.length() != 10) {
                throw new IllegalArgumentException("Invalid phone number");
            }
            contact.setPhone(phone);
        }

        if (address != null) {
            if (address.length() > 30) {
                throw new IllegalArgumentException("Invalid address");
            }
            contact.setAddress(address);
        }
    }

    /**
     * Retrieves a contact by its ID.
     * 
     * @param contactId the ID of the contact to retrieve
     * @return the contact with the specified ID, or null if no such contact exists
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}