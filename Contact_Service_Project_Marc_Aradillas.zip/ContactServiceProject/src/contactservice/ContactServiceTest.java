package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the ContactService class.
 */
public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    /**
     * Test to verify that a contact can be added to the service.
     */
    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    /**
     * Test to verify that adding a duplicate contact throws an exception.
     */
    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact);
        });
    }

    /**
     * Test to verify that a contact can be deleted from the service.
     */
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    /**
     * Test to verify that deleting a non-existent contact throws an exception.
     */
    @Test
    public void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("12345");
        });
    }

    /**
     * Test to verify that a contact can be updated in the service.
     */
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("12345", "Jane", "Smith", "0987654321", "456 Elm St");
        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Elm St", updatedContact.getAddress());
    }

    /**
     * Test to verify that updating a contact with invalid fields throws an exception.
     */
    @Test
    public void testUpdateContactWithInvalidFields() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        
        // Invalid first name
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "JaneJaneJaneJane", "Doe", "0987654321", "456 Main St");
        });

        // Invalid last name
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "Jane", "DoeDoeDoeDoe", "0987654321", "456 Main St");
        });

        // Invalid phone number
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "Jane", "Doe", "09876543", "456 Main St");
        });

        // Invalid address
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "Jane", "Doe", "0987654321", "This address is way too long to be valid according to the requirements");
        });
    }

    /**
     * Test to verify that updating a non-existent contact throws an exception.
     */
    @Test
    public void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "Jane", "Doe", "0987654321", "456 Main St");
        });
    }

    /**
     * Test to verify that a contact can be retrieved by its ID.
     */
    @Test
    public void testGetContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    /**
     * Test to verify that retrieving a non-existent contact returns null.
     */
    @Test
    public void testGetNonExistentContact() {
        assertNull(contactService.getContact("12345"));
    }

    /**
     * Test to verify that updating a contact with only valid fields.
     */
    @Test
    public void testPartialUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        
        // Only update first name
        contactService.updateContact("12345", "Jane", null, null, null);
        assertEquals("Jane", contactService.getContact("12345").getFirstName());
        
        // Only update last name
        contactService.updateContact("12345", null, "Smith", null, null);
        assertEquals("Smith", contactService.getContact("12345").getLastName());
        
        // Only update phone
        contactService.updateContact("12345", null, null, "0987654321", null);
        assertEquals("0987654321", contactService.getContact("12345").getPhone());
        
        // Only update address
        contactService.updateContact("12345", null, null, null, "456 Elm St");
        assertEquals("456 Elm St", contactService.getContact("12345").getAddress());
    }
}