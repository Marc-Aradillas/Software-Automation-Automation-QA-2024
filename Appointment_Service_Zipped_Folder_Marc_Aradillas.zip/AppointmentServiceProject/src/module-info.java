/**
 * 
 */
/**
 * 
 */
module AppointmentServiceProject {
	requires org.junit.jupiter.api;
}