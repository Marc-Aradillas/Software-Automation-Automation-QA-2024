package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        // Create a future date for testing
        Date futureDate = getFutureDate();
        // Create an Appointment object with valid inputs
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        // Assert that the appointment's fields match the expected values
        assertEquals("123", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Check-up", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = getFutureDate();
        // Test with null ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Check-up");
        });
        // Test with ID longer than 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Check-up");
        });
        
        // Test for valid appointmentId
        Appointment appointment = new Appointment("1234567890", futureDate, "Check-up");
        assertNotNull(appointment);
        assertEquals("1234567890", appointment.getAppointmentId());
    }

    @Test
    public void testInvalidAppointmentDate() {
        // Test with past date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", new Date(System.currentTimeMillis() - 1000), "Check-up");
        });
        // Test with null date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Check-up");
        });
        
     // Test for valid appointmentDate
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        assertNotNull(appointment);
        assertEquals(futureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = getFutureDate();
        // Test with null description
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null);
        });
        // Test with description longer than 50 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "This description is definitely way too long and exceeds the 50 characters limit set by the system specifications");
        });
        
     // Test for valid description
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        assertNotNull(appointment);
        assertEquals("Check-up", appointment.getDescription());
    }

    @Test
    public void testSetDescription() {
        Date futureDate = getFutureDate();
        // Create an Appointment object with valid inputs
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        // Update the description of the appointment
        appointment.setDescription("Follow-up");
        // Assert that the updated description matches the expected value
        assertEquals("Follow-up", appointment.getDescription());
    }

    @Test
    public void testSetInvalidDescription() {
        Date futureDate = getFutureDate();
        // Create an Appointment object with valid inputs
        Appointment appointment = new Appointment("123", futureDate, "Check-up");
        // Test setting a null description
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
        // Test setting a description longer than 50 characters
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is definitely way too long and exceeds the 50 characters limit set by the system specifications");
        });
    }

    @Test
    public void testGetters() {
        // Test that all getters return the expected values
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("456", futureDate, "Consultation");
        assertEquals("456", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Consultation", appointment.getDescription());
    }

    // Utility method to get a future date
    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // set to tomorrow
        return calendar.getTime();
    }
}