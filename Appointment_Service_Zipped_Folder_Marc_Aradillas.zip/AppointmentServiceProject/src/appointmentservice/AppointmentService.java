package appointmentservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Service to manage appointments. 
 * The appointment service allows adding and deleting appointments.
 */
public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Adds a new appointment to the service.
     * 
     * @param appointment the appointment to add, must have a unique appointment ID
     * @throws IllegalArgumentException if an appointment with the same ID already exists
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment already exists or is null");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Deletes an appointment from the service.
     * 
     * @param appointmentId the ID of the appointment to delete
     * @throws IllegalArgumentException if the appointment ID does not exist
     */
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an appointment by its ID.
     * 
     * @param appointmentId the ID of the appointment to retrieve
     * @return the appointment with the specified ID, or null if no such appointment exists
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}