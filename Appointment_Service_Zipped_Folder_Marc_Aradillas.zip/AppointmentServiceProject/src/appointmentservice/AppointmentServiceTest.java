package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
    private AppointmentService service;

    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
    }

    @Test
    public void testAddNullAppointment() {
        // Test adding a null appointment should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    public void testAddAppointmentWithExistingId() {
        Date futureDate = getFutureDate();
        Appointment appointment1 = new Appointment("123", futureDate, "Initial Appointment");
        service.addAppointment(appointment1);
        // Test adding another appointment with the same ID should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment1));
    }

    @Test
    public void testDeleteNonexistentAppointment() {
        // Test deleting an appointment that does not exist should throw an exception
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("999"));
    }

    @Test
    public void testAddAndRetrieveAppointment() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("123", futureDate, "Initial Appointment");
        service.addAppointment(appointment);
        assertEquals(appointment, service.getAppointment("123"));
    }

    @Test
    public void testDeleteAppointment() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("123", futureDate, "Initial Appointment");
        service.addAppointment(appointment);
        service.deleteAppointment("123");
        assertNull(service.getAppointment("123"));
    }

    @Test
    public void testRetrieveNonExistentAppointment() {
        assertNull(service.getAppointment("999"));
    }

    private Date getFutureDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 1); // Ensure the date is in the future
        return calendar.getTime();
    }
}