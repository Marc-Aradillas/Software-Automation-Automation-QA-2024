package appointmentservice;

import java.util.Date;

/**
 * Class representing an appointment with a unique ID, a date, and a description.
 */
public class Appointment {
    private final String appointmentId; // Unique identifier for the appointment
    private final Date appointmentDate; // Date of the appointment
    private String description; // Description of the appointment

    /**
     * Constructor to initialize the appointment object with required fields.
     * 
     * @param appointmentId the unique ID for the appointment, must not be null and must not exceed 10 characters
     * @param appointmentDate the date of the appointment, must not be null and must not be in the past
     * @param description the description of the appointment, must not be null and must not exceed 50 characters
     * @throws IllegalArgumentException if any parameter is invalid
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    /**
     * Gets the appointment ID.
     * 
     * @return the appointment ID
     */
    public String getAppointmentId() {
        return appointmentId;
    }

    /**
     * Gets the appointment date.
     * 
     * @return the appointment date
     */
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    /**
     * Gets the description.
     * 
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description.
     * 
     * @param description the new description, must not be null and must not exceed 50 characters
     * @throws IllegalArgumentException if the description is invalid
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}