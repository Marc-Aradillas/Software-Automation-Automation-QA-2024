package taskservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class to manage tasks using in-memory storage.
 */
public class TaskService {
    private Map<String, Task> tasks = new HashMap<>(); // Stores tasks using their ID as the key.

    /**
     * Adds a task to the service.
     * @param task The task to add.
     * @throws IllegalArgumentException If the task is null or a duplicate.
     */
    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task already exists or task is null");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task based on its ID.
     * @param taskId The ID of the task to delete.
     * @throws IllegalArgumentException If the task ID is not found.
     */
    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    /**
     * Retrieves a task by its ID.
     * @param taskId The ID of the task to retrieve.
     * @return The task, or null if it does not exist.
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    /**
     * Updates an existing task's name by task ID.
     * @param taskId The ID of the task to update.
     * @param newName The new name for the task.
     * @throws IllegalArgumentException If the task ID is not found or if the new name is invalid.
     */
    public void updateTaskNameById(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setName(newName);
    }

    /**
     * Updates an existing task's description by task ID.
     * @param taskId The ID of the task to update.
     * @param newDescription The new description for the task.
     * @throws IllegalArgumentException If the task ID is not found or if the new description is invalid.
     */
    public void updateTaskDescriptionById(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setDescription(newDescription);
    }
}