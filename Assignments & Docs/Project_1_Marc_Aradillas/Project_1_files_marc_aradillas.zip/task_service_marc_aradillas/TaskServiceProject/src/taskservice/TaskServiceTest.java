package taskservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the TaskService class.
 */
public class TaskServiceTest {
    private TaskService service;

    /**
     * Sets up the TaskService before each test.
     * This method is executed before each test method in this class.
     * It initializes a new TaskService instance to ensure tests do not affect each other.
     */
    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    /**
     * Test to verify that a task can be added and retrieved successfully.
     * Ensures the added task is stored correctly and can be retrieved using its ID.
     */
    @Test
    public void testAddAndRetrieveTask() {
        Task task = new Task("123", "Initial Task", "Initial Description");
        service.addTask(task);
        assertEquals(task, service.getTask("123"));
    }

    /**
     * Test to verify that adding a duplicate task throws an exception.
     * Confirms that the service does not allow two tasks with the same ID.
     */
    @Test
    public void testAddDuplicateTask() {
        Task task = new Task("123", "Initial Task", "Initial Description");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task);
        });
    }

    /**
     * Test to verify that a task can be deleted successfully.
     * Checks that after deletion, the task cannot be retrieved.
     */
    @Test
    public void testDeleteTask() {
        Task task = new Task("123", "Initial Task", "Initial Description");
        service.addTask(task);
        service.deleteTask("123");
        assertNull(service.getTask("123"));
    }

    /**
     * Test to verify that a task's name can be updated successfully.
     * Ensures that updating the name of a task works as expected.
     */
    @Test
    public void testUpdateTaskNameById() {
        Task task = new Task("123", "Initial Task", "Initial Description");
        service.addTask(task);
        service.updateTaskNameById("123", "Updated Name");
        Task updatedTask = service.getTask("123");
        assertEquals("Updated Name", updatedTask.getName());
    }

    /**
     * Test to verify that a task's description can be updated successfully.
     * Ensures that updating the description of a task works as expected.
     */
    @Test
    public void testUpdateTaskDescriptionById() {
        Task task = new Task("123", "Initial Task", "Initial Description");
        service.addTask(task);
        service.updateTaskDescriptionById("123", "Updated Description");
        Task updatedTask = service.getTask("123");
        assertEquals("Updated Description", updatedTask.getDescription());
    }

    /**
     * Test to verify that updating a non-existent task's name throws an exception.
     * Ensures the service throws an error if an update is attempted on a task ID that does not exist.
     */
    @Test
    public void testNonExistentTaskNameUpdate() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskNameById("999", "Updated Name");
        });
    }

    /**
     * Test to verify that updating a non-existent task's description throws an exception.
     * Ensures the service throws an error if an update is attempted on a task ID that does not exist.
     */
    @Test
    public void testNonExistentTaskDescriptionUpdate() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTaskDescriptionById("999", "Updated Description");
        });
    }
}