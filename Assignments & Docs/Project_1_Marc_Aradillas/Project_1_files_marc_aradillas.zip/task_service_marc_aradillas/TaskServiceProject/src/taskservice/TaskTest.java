package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Task class.
 */
public class TaskTest {

    /**
     * Test to verify that an exception is thrown for invalid task names.
     * This test checks for null, empty, and overly long task names.
     */
    @Test
    public void testInvalidTaskName() {
        // Test to verify that an exception is thrown when the name is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Task Description");
        });

        // Test to verify that an exception is thrown when the name is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is definitely way too long for the task", "Task Description");
        });

        // Test to verify that an exception is thrown when the name is empty
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "", "Task Description");
        });
    }

    /**
     * Test to verify that an exception is thrown for invalid task descriptions.
     * This test checks for null, empty, and overly long descriptions.
     */
    @Test
    public void testInvalidTaskDescription() {
        // Test to verify that an exception is thrown when the description is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", null);
        });

        // Test to verify that an exception is thrown when the description is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", "This description is definitely way too long and exceeds the 50 characters limit set by the system specifications");
        });

        // Test to verify that an exception is thrown when the description is empty
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", "");
        });
    }

    /**
     * Test to verify successful creation of a Task object with valid inputs.
     * Confirms that the task's fields are set correctly when valid inputs are provided.
     */
    @Test
    public void testTaskCreationWithValidInputs() {
        // Confirming that a Task object is created successfully with valid inputs
        Task task = new Task("12345", "Task Name", "Task Description");
        assertNotNull(task);
        assertEquals("12345", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    /**
     * Test to verify that an exception is thrown for a task ID that is too long.
     * Ensures that task ID validation works as expected for length constraints.
     */
    @Test
    public void testTaskCreationWithLongId() {
        // Test to verify that an exception is thrown when the taskId is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Task Description");
        });
    }

    /**
     * Test to verify that an exception is thrown for a null task ID.
     * Ensures that task ID validation correctly handles null values.
     */
    @Test
    public void testTaskCreationWithNullId() {
        // Test to verify that an exception is thrown when the taskId is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Task Description");
        });
    }

    /**
     * Test to verify the setter for task name with invalid values.
     * This test checks for null, empty, and overly long names.
     */
    @Test
    public void testSetInvalidName() {
        Task task = new Task("12345", "Task Name", "Task Description");

        // Test to verify that an exception is thrown when setting a null name
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });

        // Test to verify that an exception is thrown when setting a too long name
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("This name is definitely way too long for the task");
        });

        // Test to verify that an exception is thrown when setting an empty name
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("");
        });
    }

    /**
     * Test to verify the setter for task description with invalid values.
     * This test checks for null, empty, and overly long descriptions.
     */
    @Test
    public void testSetInvalidDescription() {
        Task task = new Task("12345", "Task Name", "Task Description");

        // Test to verify that an exception is thrown when setting a null description
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });

        // Test to verify that an exception is thrown when setting a too long description
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is definitely way too long and exceeds the 50 characters limit set by the system specifications");
        });

        // Test to verify that an exception is thrown when setting an empty description
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("");
        });
    }

    /**
     * Test to verify successful setting of a valid task name.
     * Ensures that the setter correctly updates the task name.
     */
    @Test
    public void testSetValidName() {
        Task task = new Task("12345", "Old Name", "Task Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    /**
     * Test to verify successful setting of a valid task description.
     * Ensures that the setter correctly updates the task description.
     */
    @Test
    public void testSetValidDescription() {
        Task task = new Task("12345", "Task Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }
}
