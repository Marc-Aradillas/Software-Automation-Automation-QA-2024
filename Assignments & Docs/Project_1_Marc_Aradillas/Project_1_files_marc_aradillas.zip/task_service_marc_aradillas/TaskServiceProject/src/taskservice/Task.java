package taskservice;

/**
 * Class representing a task with a unique identifier, name, and description.
 */
public class Task {
    private final String taskId; // Unique identifier for the task, immutable after creation.
    private String name; // Task name.
    private String description; // Detailed description of the task.

    /**
     * Constructor for Task.
     * Validates and initializes a task with given parameters.
     *
     * @param taskId Unique identifier for the task, must not be null and cannot exceed 10 characters.
     * @param name Task name, must not be null and cannot exceed 20 characters.
     * @param description Task description, must not be null and cannot exceed 50 characters.
     * @throws IllegalArgumentException If any parameter is invalid.
     */
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must not be null and must be at most 10 characters.");
        }
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Name must not be null, empty, and must be at most 20 characters.");
        }
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description must not be null, empty, and must be at most 50 characters.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters for task properties.
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setter for task name, validates the new name before setting.
    public void setName(String name) {
        if (name == null || name.isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name: Name must not be null, empty, and must be at most 20 characters.");
        }
        this.name = name;
    }

    // Setter for task description, validates the new description before setting.
    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description: Description must not be null, empty, and must be at most 50 characters.");
        }
        this.description = description;
    }
}
