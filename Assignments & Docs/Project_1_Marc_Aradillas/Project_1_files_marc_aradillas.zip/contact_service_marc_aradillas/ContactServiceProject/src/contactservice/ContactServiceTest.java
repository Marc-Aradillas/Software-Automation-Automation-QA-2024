package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the ContactService class.
 */
public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testAddDuplicateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact);
        });
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("nonexistentID");
        });
    }

    @Test
    public void testUpdateContactFirstName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactFirstName("12345", "Jane");
        assertEquals("Jane", contactService.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateContactLastName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactLastName("12345", "Smith");
        assertEquals("Smith", contactService.getContact("12345").getLastName());
    }

    @Test
    public void testUpdateContactPhone() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactPhone("12345", "0987654321");
        assertEquals("0987654321", contactService.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateContactAddress() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContactAddress("12345", "456 Elm St");
        assertEquals("456 Elm St", contactService.getContact("12345").getAddress());
    }

    @Test
    public void testUpdateNonExistentContactFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactFirstName("nonexistentID", "NewName");
        });
    }

    @Test
    public void testUpdateNonExistentContactLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactLastName("nonexistentID", "NewLastName");
        });
    }

    @Test
    public void testUpdateNonExistentContactPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactPhone("nonexistentID", "0987654321");
        });
    }

    @Test
    public void testUpdateNonExistentContactAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContactAddress("nonexistentID", "New Address 123");
        });
    }

    @Test
    public void testGetContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testGetNonExistentContact() {
        assertNull(contactService.getContact("nonexistentID"));
    }
}