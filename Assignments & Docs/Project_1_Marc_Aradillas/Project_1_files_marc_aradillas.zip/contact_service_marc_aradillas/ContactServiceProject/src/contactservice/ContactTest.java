package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

public class ContactTest {

    @Test
    public void testContactCreation() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @ParameterizedTest
    @MethodSource("provideInvalidContactId")
    public void testInvalidContactId(String contactId, String firstName, String lastName, String phone, String address) {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(contactId, firstName, lastName, phone, address);
        });
    }

    private static Stream<Arguments> provideInvalidContactId() {
        return Stream.of(
            Arguments.of("12345678901", "John", "Doe", "1234567890", "123 Main St"),  // Invalid contactId (too long)
            Arguments.of("", "John", "Doe", "1234567890", "123 Main St"),  // Invalid contactId (empty)
            Arguments.of((String) null, "John", "Doe", "1234567890", "123 Main St")  // Invalid contactId (null)
        );
    }

    @ParameterizedTest
    @MethodSource("provideInvalidFirstName")
    public void testSetInvalidFirstName(String firstName) {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(firstName);
        });
    }

    private static Stream<Arguments> provideInvalidFirstName() {
        return Stream.of(
            Arguments.of((String) null),  // Null first name
            Arguments.of(""),  // Empty first name
            Arguments.of("JohnJohnJohnJohn")  // Too long first name
        );
    }

    @ParameterizedTest
    @MethodSource("provideInvalidLastName")
    public void testSetInvalidLastName(String lastName) {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(lastName);
        });
    }

    private static Stream<Arguments> provideInvalidLastName() {
        return Stream.of(
            Arguments.of((String) null),  // Null last name
            Arguments.of(""),  // Empty last name
            Arguments.of("DoeDoeDoeDoeDoe")  // Too long last name
        );
    }

    @ParameterizedTest
    @MethodSource("provideInvalidPhone")
    public void testSetInvalidPhone(String phone) {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone(phone);
        });
    }

    private static Stream<Arguments> provideInvalidPhone() {
        return Stream.of(
            Arguments.of((String) null),  // Null phone number
            Arguments.of("12345"),  // Too short
            Arguments.of("12345678901"),  // Too long
            Arguments.of("abcdefghij")  // Not numeric
        );
    }

    @ParameterizedTest
    @MethodSource("provideInvalidAddress")
    public void testSetInvalidAddress(String address) {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(address);
        });
    }

    private static Stream<Arguments> provideInvalidAddress() {
        return Stream.of(
            Arguments.of((String) null),  // Null address
            Arguments.of(""),  // Empty string
            Arguments.of("This address is way too long to be valid according to the requirements")  // Too long address
        );
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contact.setAddress("456 Elm St");
        assertEquals("456 Elm St", contact.getAddress());
    }

    @Test
    public void testGetters() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }
}
