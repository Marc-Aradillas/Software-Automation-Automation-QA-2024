package contactservice;

import java.util.HashMap;
import java.util.Map;

/**
 * Service to manage contacts.
 * The contact service allows adding, updating, and deleting contacts.
 */
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the service.
     * 
     * @param contact the contact to add, must have a unique contact ID
     * @throws IllegalArgumentException if a contact with the same ID already exists
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    /**
     * Deletes a contact from the service.
     * 
     * @param contactId the ID of the contact to delete
     * @throws IllegalArgumentException if the contact ID does not exist
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contacts.remove(contactId);
    }

    /**
     * Updates an existing contact's first name.
     * 
     * @param contactId the ID of the contact to update
     * @param firstName the new first name
     * @throws IllegalArgumentException if the contact ID does not exist or first name is invalid
     */
    public boolean updateContactFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setFirstName(firstName);
        return true;
    }

    /**
     * Updates an existing contact's last name.
     * 
     * @param contactId the ID of the contact to update
     * @param lastName the new last name
     * @throws IllegalArgumentException if the contact ID does not exist or last name is invalid
     */
    public boolean updateContactLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setLastName(lastName);
        return true;
    }

    /**
     * Updates an existing contact's phone number.
     * 
     * @param contactId the ID of the contact to update
     * @param phone the new phone number
     * @throws IllegalArgumentException if the contact ID does not exist or phone number is invalid
     */
    public boolean updateContactPhone(String contactId, String phone) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setPhone(phone);
        return true;
    }

    /**
     * Updates an existing contact's address.
     * 
     * @param contactId the ID of the contact to update
     * @param address the new address
     * @throws IllegalArgumentException if the contact ID does not exist or address is invalid
     */
    public boolean updateContactAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found");
        }
        contact.setAddress(address);
        return true;
    }

    /**
     * Retrieves a contact by its ID.
     * 
     * @param contactId the ID of the contact to retrieve
     * @return the contact with the specified ID, or null if no such contact exists
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
