/**
 * 
 */
/**
 * 
 */
module ContactServiceProject {
	requires org.junit.jupiter.api;
	requires org.junit.jupiter.params;
}