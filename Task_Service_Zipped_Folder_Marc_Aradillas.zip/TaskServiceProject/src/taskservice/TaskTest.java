package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Task class.
 */
public class TaskTest {

    /**
     * Test to verify that an exception is thrown for invalid task names.
     * This test checks for both null and overly long task names.
     */
    @Test
    public void testInvalidTaskName() {
        // Test to verify that an exception is thrown when the name is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Task Description");
        });

        // Test to verify that an exception is thrown when the name is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "This name is definitely way too long for the task", "Task Description");
        });
    }

    /**
     * Test to verify that an exception is thrown for invalid task descriptions.
     * This test checks for both null and overly long descriptions.
     */
    @Test
    public void testInvalidTaskDescription() {
        // Test to verify that an exception is thrown when the description is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", null);
        });

        // Test to verify that an exception is thrown when the description is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Task Name", "This description is definitely way too long and exceeds the 50 characters limit set by the system specifications");
        });
    }

    /**
     * Test to verify successful creation of a Task object with valid inputs.
     * Confirms that the task's fields are set correctly when valid inputs are provided.
     */
    @Test
    public void testTaskCreationWithValidInputs() {
        // Confirming that a Task object is created successfully with valid inputs
        Task task = new Task("12345", "Task Name", "Task Description");
        assertNotNull(task);
        assertEquals("12345", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    /**
     * Test to verify that an exception is thrown for a task ID that is too long.
     * Ensures that task ID validation works as expected for length constraints.
     */
    @Test
    public void testTaskCreationWithLongId() {
        // Test to verify that an exception is thrown when the taskId is too long
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Task Name", "Task Description");
        });
    }

    /**
     * Test to verify that an exception is thrown for a null task ID.
     * Ensures that task ID validation correctly handles null values.
     */
    @Test
    public void testTaskCreationWithNullId() {
        // Test to verify that an exception is thrown when the taskId is null
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Task Description");
        });
    }
}
