/**
 * 
 */
/**
 * 
 */
module TaskServiceProject {
	requires org.junit.jupiter.api;
}